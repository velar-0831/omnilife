# 🌟 OmniLife - 全域生活平台

> 一个集成AI驱动的音乐、新闻、购物、汽车服务和生活服务的综合平台

## 🚀 快速开始

### 在线演示
- **主应用**: [部署到Vercel后的链接]
- **演示版本**: [omnilife-demo部署链接]

### 本地运行

```bash
# 克隆仓库
git clone https://github.com/velar-0831/omnilife.git

# 进入主项目目录
cd omnilife/omnilife

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

访问 http://localhost:3000

## 📁 项目结构

```
omnilife/
├── omnilife/          # 主应用程序
│   ├── app/           # Next.js App Router
│   ├── src/           # 源代码
│   │   ├── components/    # React组件
│   │   ├── stores/        # Zustand状态管理
│   │   ├── lib/           # 工具函数
│   │   └── types/         # TypeScript类型
│   ├── public/        # 静态资源
│   └── package.json   # 依赖配置
├── omnilife-demo/     # 演示版本
└── docs/              # 文档
```

## 🎯 核心功能

### 🎵 音乐模块
- **AI音乐推荐**: 基于用户喜好的智能推荐
- **播放列表管理**: 创建和管理个人播放列表
- **实时歌词**: 同步显示歌词
- **音质选择**: 多种音质选项

### 📰 新闻模块
- **个性化推荐**: AI驱动的新闻推荐
- **分类浏览**: 科技、娱乐、体育等分类
- **实时更新**: 24/7新闻更新
- **多语言支持**: 中英文切换

### 🛒 购物模块
- **智能推荐**: 基于购买历史的商品推荐
- **购物车**: 完整的购物车功能
- **支付集成**: 多种支付方式
- **订单跟踪**: 实时订单状态

### 🚗 汽车服务
- **车辆管理**: 多车辆信息管理
- **维修记录**: 详细的维修历史
- **保险提醒**: 保险到期提醒
- **加油记录**: 油耗统计分析

### 🏠 生活服务
- **家政服务**: 清洁、维修等服务预约
- **社区团购**: 邻里团购功能
- **便民服务**: 水电缴费等
- **预约管理**: 服务预约和管理

## 🛠️ 技术栈

### 前端技术
- **Next.js 14**: React全栈框架
- **TypeScript**: 类型安全
- **Tailwind CSS**: 原子化CSS
- **Framer Motion**: 动画库
- **Radix UI**: 无障碍UI组件

### 状态管理
- **Zustand**: 轻量级状态管理

### 开发工具
- **ESLint**: 代码规范
- **Prettier**: 代码格式化
- **Husky**: Git钩子
- **Jest**: 单元测试
- **Playwright**: E2E测试

### 部署
- **Vercel**: 主要部署平台
- **Docker**: 容器化部署

## 🎨 设计特色

### 🌙 深色主题
- 现代化深色界面
- 护眼的配色方案
- 霓虹灯效果点缀

### 📱 响应式设计
- 移动端优先设计
- 平板和桌面端适配
- 流畅的交互体验

### ⚡ 性能优化
- 代码分割和懒加载
- 图片优化
- 缓存策略

## 🚀 部署指南

### Vercel部署（推荐）

1. Fork此仓库
2. 在Vercel中导入项目
3. 设置根目录为 `omnilife`
4. 部署

### Docker部署

```bash
# 构建镜像
docker build -t omnilife .

# 运行容器
docker run -p 3000:3000 omnilife
```

## 🤝 贡献指南

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 📞 联系方式

- **开发者**: velar-0831
- **GitHub**: https://github.com/velar-0831
- **项目链接**: https://github.com/velar-0831/omnilife

## 🙏 致谢

感谢所有为这个项目做出贡献的开发者和设计师！

---

**让生活更智能，让服务更便捷！** 🌟
